import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const J7App());

class J7App extends StatelessWidget {
  const J7App({super.key});

  @override
  Widget build(BuildContext context) {
    const bg = Color(0xFF090D16);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'J7 Topaz AI Mobile',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF00D9FF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
        sliderTheme: const SliderThemeData(
          activeTrackColor: Color(0xFF00D9FF),
          thumbColor: Color(0xFF00D9FF),
        ),
      ),
      home: const EditorPage(),
    );
  }
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  final picker = ImagePicker();
  XFile? selectedImage;
  XFile? selectedVideo;
  VideoPlayerController? videoController;
  double sharpness = 45, denoise = 35, detail = 60, brightness = 50;
  String resolution = '4K';
  bool faceEnhance = false;
  bool isBusy = false;

  Future<void> chooseImage() async {
    final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 100);
    if (file == null) return;
    await videoController?.dispose();
    setState(() {
      selectedImage = file;
      selectedVideo = null;
      videoController = null;
    });
  }

  Future<void> chooseVideo() async {
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    await videoController?.dispose();
    final controller = VideoPlayerController.file(File(file.path));
    await controller.initialize();
    setState(() {
      selectedVideo = file;
      selectedImage = null;
      videoController = controller;
    });
  }

  @override
  void dispose() {
    videoController?.dispose();
    super.dispose();
  }

  Widget panel({required String title, required Widget child, IconData? icon}) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF121A29),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFF24364C)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          if (icon != null) ...[Icon(icon, color: const Color(0xFF00D9FF), size: 19), const SizedBox(width: 9)],
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ]),
        const SizedBox(height: 14),
        child,
      ]),
    );
  }

  Widget adjustment(String name, double value, ValueChanged<double> onChanged) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(name, style: const TextStyle(color: Colors.white70)),
        Text('${value.round()}%', style: const TextStyle(color: Color(0xFF00D9FF), fontWeight: FontWeight.bold)),
      ]),
      Slider(value: value, min: 0, max: 100, onChanged: onChanged),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF090D16),
        title: const Row(children: [
          Icon(Icons.auto_awesome, color: Color(0xFF00D9FF)),
          SizedBox(width: 9),
          Text('J7 TOPAZ AI', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        ]),
        actions: const [Padding(padding: EdgeInsets.only(right: 16), child: Center(child: Text('MOBILE', style: TextStyle(color: Color(0xFF00D9FF), fontSize: 11, letterSpacing: 2))))],
      ),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF142B42), Color(0xFF101727)]),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF00D9FF).withOpacity(.35)),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('APRIMORAMENTO DE MÍDIA', style: TextStyle(color: Color(0xFF00D9FF), fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('Mais detalhes. Mais definição.', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800)),
              SizedBox(height: 5),
              Text('Escolha uma foto ou vídeo e configure os ajustes.', style: TextStyle(color: Colors.white60)),
            ]),
          ),
          const SizedBox(height: 16),
          panel(title: 'Importar mídia', icon: Icons.add_photo_alternate_outlined, child: Row(children: [
            Expanded(child: FilledButton.icon(onPressed: chooseImage, icon: const Icon(Icons.image), label: const Text('Foto'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: chooseVideo, icon: const Icon(Icons.video_library), label: const Text('Vídeo'))),
          ])),
          panel(title: 'Pré-visualização', icon: Icons.preview, child: Container(
            height: 230, width: double.infinity,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: const Color(0xFF080C13), borderRadius: BorderRadius.circular(14)),
            child: selectedImage != null
                ? ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(selectedImage!.path), fit: BoxFit.contain, width: double.infinity, height: 230))
                : videoController != null
                    ? AspectRatio(aspectRatio: videoController!.value.aspectRatio, child: Stack(alignment: Alignment.center, children: [
                        VideoPlayer(videoController!),
                        IconButton.filled(onPressed: () => setState(() => videoController!.value.isPlaying ? videoController!.pause() : videoController!.play()), icon: Icon(videoController!.value.isPlaying ? Icons.pause : Icons.play_arrow)),
                      ]))
                    : const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(Icons.cloud_upload_outlined, size: 48, color: Color(0xFF49647E)),
                        SizedBox(height: 10),
                        Text('Nenhum arquivo selecionado', style: TextStyle(color: Colors.white54)),
                      ]),
          )),
          panel(title: 'Ajustes de aprimoramento', icon: Icons.tune, child: Column(children: [
            adjustment('Nitidez', sharpness, (v) => setState(() => sharpness = v)),
            adjustment('Redução de ruído', denoise, (v) => setState(() => denoise = v)),
            adjustment('Recuperação de detalhes', detail, (v) => setState(() => detail = v)),
            adjustment('Brilho', brightness, (v) => setState(() => brightness = v)),
            SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Realce de rosto'), subtitle: const Text('Opção de configuração para futuras versões'), value: faceEnhance, onChanged: (v) => setState(() => faceEnhance = v)),
          ])),
          panel(title: 'Resolução de saída', icon: Icons.high_quality, child: Wrap(spacing: 8, children: ['720p', '1080p', '2K', '4K'].map((r) => ChoiceChip(label: Text(r), selected: resolution == r, onSelected: (_) => setState(() => resolution = r))).toList())),
          FilledButton.icon(
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54), backgroundColor: const Color(0xFF00B9DB), foregroundColor: const Color(0xFF001018)),
            onPressed: () {
              final hasMedia = selectedImage != null || selectedVideo != null;
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                content: Text(!hasMedia ? 'Importe uma foto ou vídeo primeiro.' : 'Configurações salvas na interface. O processamento/exportação ainda será implementado.'),
              ));
            },
            icon: const Icon(Icons.auto_fix_high),
            label: const Text('APRIMORAR MÍDIA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
          ),
          const SizedBox(height: 14),
          const Text('Aviso: esta versão é uma base funcional de interface e importação/visualização. Os controles ainda não aplicam processamento real de IA nem exportam arquivos em 4K.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 11)),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }
}
